"use client";

import { useRouter } from "next/navigation";
import { useAuth } from "@/app/hooks/useAuth";

export default function EmployeeDashboard() {
  const router = useRouter();
  // ✅ Auth + user in one hook call — no repeated useEffect boilerplate
  const { user, loading, logout } = useAuth({ requiredRole: "employee" });

  if (loading) return null;

  function calculate() {
    const salary   = parseFloat((document.getElementById("salary")   as HTMLInputElement)?.value || "0");
    const bonus    = parseFloat((document.getElementById("bonus")    as HTMLInputElement)?.value || "0");
    const absents  = parseFloat((document.getElementById("absents")  as HTMLInputElement)?.value || "0");
    const expenses = parseFloat((document.getElementById("expenses") as HTMLInputElement)?.value || "0");

    const daily        = salary / 30;
    const absentTotal  = daily * absents;
    const tot  = salary + bonus + expenses 
    const finalSalary = tot - absentTotal;

    const dailyEl  = document.getElementById("daily");
    const absentEl = document.getElementById("absentTotal");
    const finalEl  = document.getElementById("finalSalary");

    if (dailyEl)  dailyEl.innerText  = daily.toFixed(2);
    if (absentEl) absentEl.innerText = absentTotal.toFixed(2);
    if (finalEl)  finalEl.innerText  = finalSalary.toFixed(2);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F7FF] to-[#ce908b] flex justify-center p-4">
      <div className="w-full max-w-5xl flex flex-col gap-6">

        {/* HEADER */}
        <div className="bg-white/60 backdrop-blur-xl border border-[#ec510e]/20 rounded-2xl p-4 flex items-center justify-between">
          {/* Left — Home button */}
          <button
            onClick={() => router.push("/home")}
            className="px-4 py-2 text-sm text-white rounded-full bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
          >
            ← Home
          </button>

          {/* Center — Title */}
          <div className="text-center">
            <h1 className="text-2xl font-bold text-[#ec510e]">Employee Dashboard</h1>
            <p className="text-sm text-gray-700">
              Welcome dear,
              <span className="font-semibold text-black ml-1">{user?.firstName || "..."}</span>
            </p>
          </div>

          {/* Right — Logout button */}
          <button
            onClick={logout}
            className="px-4 py-2 text-sm text-white rounded-full bg-gradient-to-r from-red-500 to-red-400"
          >
            Logout →
          </button>
        </div>

        {/* FORM */}
        <div className="bg-white/60 backdrop-blur-xl border border-[#ec510e]/20 rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <input id="salary"   type="number" placeholder="Base Salary"  className="p-3 rounded-lg border bg-white text-black" />
          <input id="bonus"    type="number" placeholder="Bonus"        className="p-3 rounded-lg border bg-white text-black" />
          <input id="absents"  type="number" placeholder="Absent Days"  className="p-3 rounded-lg border bg-white text-black" />
          <input id="expenses" type="number" placeholder="Expenses"     className="p-3 rounded-lg border bg-white text-black" />
          <button
            onClick={calculate}
            className="md:col-span-2 py-3 rounded-full text-white font-semibold bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
          >
            Calculate
          </button>
        </div>

        {/* RESULT */}
        <div className="bg-white/60 backdrop-blur-xl border border-[#ec510e]/20 rounded-2xl p-6 text-center">
          <h2 className="text-lg font-semibold text-[#ec510e] mb-4">Result</h2>
          <p className="text-black">Daily Deduction: <span id="daily"       className="font-semibold" /></p>
          <p className="text-black">Absent Deduction: <span id="absentTotal" className="font-semibold" /></p>
          <p className="text-black">Final Salary: <span id="finalSalary"  className="font-semibold" /></p>
        </div>

        {/* BUTTONS */}
        <div className="flex flex-wrap justify-center gap-3">
          {[
            { label: "Request Vacation", path: "/veccation" },
            { label: "Appliance",        path: "/appeal"     },
            { label: "Suggestions",      path: "/suggestions"},
            { label: "Resignation",      path: "/resignation"},
          ].map(({ label, path }) => (
            <button
              key={path}
              onClick={() => router.push(path)}
              className="px-6 py-3 rounded-full text-white bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
            >
              {label}
            </button>
          ))}
        </div>

      </div>
    </div>
  );
}
