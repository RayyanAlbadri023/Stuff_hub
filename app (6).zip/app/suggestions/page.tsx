"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/app/hooks/useAuth";
import { useRequest } from "@/app/hooks/useRequest";

export default function Page() {
  const router = useRouter();
  // ✅ One hook handles auth — no repeated useEffect
  const { user, loading } = useAuth();
  // ✅ Hook handles fetch state — no raw Promise in component
  const { execute, loading: submitting, error } = useRequest();

  const [message, setMessage] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  if (loading) return null;

  async function sendRequest() {
    if (!message.trim()) return alert("Please write your suggestion");

    const result = await execute("/api/requests", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name:    user?.firstName || "Employee",
        email:   user?.email    || "",
        type:    "suggestion",
        message,
      }),
    });

    if (!result) return;

    setSuccessMsg("Send Suggestion sent successfully ✅");
    setMessage("");
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F7FF] to-[#ce908b] flex items-center justify-center p-5">
      <div className="w-full max-w-lg bg-white/60 backdrop-blur-xl p-6 rounded-2xl border border-[#ec510e]/20">
        <h1 className="text-xl font-bold text-[#ec510e] text-center mb-4">
          Send Suggestion to Manager
        </h1>

        {error      && <p className="text-red-500 text-sm mb-2">{error}</p>}
        {successMsg && <p className="text-green-600 text-sm mb-2">{successMsg}</p>}

        <textarea
          placeholder="Write your suggestion here..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="w-full h-40 p-3 rounded-lg border border-gray-300 outline-none resize-none bg-white/80 text-black placeholder-gray-500"
        />

        <button
          onClick={sendRequest}
          disabled={submitting}
          className="w-full mt-4 py-3 rounded-full text-white font-semibold bg-gradient-to-r from-[#ec510e] to-[#ecbcaf] disabled:opacity-60"
        >
          {submitting ? "Sending..." : "Send Suggestion"}
        </button>

        <button onClick={() => router.push("/employee")}
          className="w-full mt-3 py-2 text-sm text-gray-700 underline">
          Back to Dashboard
        </button>
      </div>
    </div>
  );
}
