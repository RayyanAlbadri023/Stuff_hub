import { NextResponse } from "next/server";

/**
 * POST /api/logout
 * Clears the session cookie. The client should also clear localStorage.
 */
export async function POST() {
  const response = NextResponse.json({ message: "Logged out" });
  response.cookies.set("session", "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 0, // expire immediately
  });
  return response;
}
