"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export type AuthUser = {
  id?: string | number;
  firstName?: string;
  lastName?: string;
  email?: string;
  role?: string;
};

type UseAuthOptions = {
  /** Required role. If omitted, any authenticated user is allowed. */
  requiredRole?: "admin" | "employee";
  /** Where to redirect if the check fails. Defaults to "/login". */
  redirectTo?: string;
};

type UseAuthReturn = {
  user: AuthUser | null;
  /** True while the auth check is still running (avoid flash of protected content). */
  loading: boolean;
  logout: () => void;
};

/**
 * useAuth
 *
 * Drop-in hook that:
 *  1. Reads `user` from localStorage.
 *  2. Redirects to `redirectTo` (default "/login") when the user is missing or wrong role.
 *  3. Exposes `user`, `loading`, and `logout`.
 *
 * Usage:
 *   const { user, loading, logout } = useAuth();               // any logged-in user
 *   const { user, loading, logout } = useAuth({ requiredRole: "admin" });
 */
export function useAuth(options: UseAuthOptions = {}): UseAuthReturn {
  const { requiredRole, redirectTo = "/login" } = options;
  const router = useRouter();

  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("user");

    if (!stored) {
      router.replace(redirectTo);
      return;
    }

    let parsed: AuthUser | null = null;
    try {
      parsed = JSON.parse(stored) as AuthUser;
    } catch {
      localStorage.removeItem("user");
      router.replace(redirectTo);
      return;
    }

    if (requiredRole && parsed.role !== requiredRole) {
      // Wrong role — send back to login (or a 403 page)
      router.replace(redirectTo);
      return;
    }

    setUser(parsed);
    setLoading(false);
  }, [router, requiredRole, redirectTo]);

  const logout = () => {
    localStorage.clear();
    router.replace("/login");
  };

  return { user, loading, logout };
}
