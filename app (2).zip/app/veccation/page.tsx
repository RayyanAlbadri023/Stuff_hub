"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";


type User = {
  id?: string;
  firstName?: string;
  email?: string;
};

export default function VacationPage() {
  const router = useRouter();

  const [start, setStart] = useState<string>("");
  const [end, setEnd] = useState<string>("");

  function calculateDays(start: string, end: string): number {
    const s = new Date(start);
    const e = new Date(end);
    const diff = (e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24);
    return diff + 1;
  }

  function validateDate(dateStr: string): string | null {
    const date = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (date < today) return "Past date not allowed";

    const day = date.getDay();
    if (day === 5 || day === 6) return "Weekend (Friday/Saturday) not allowed";

    return null;
  }

  async function generateReport() {
    if (!start || !end) {
      alert("Please select dates");
      return;
    }

    const startError = validateDate(start);
    const endError = validateDate(end);

    if (startError) return alert(startError);
    if (endError) return alert(endError);

    if (new Date(end) < new Date(start)) {
      alert("End date must be after start date");
      return;
    }

    let user: User | null = null;
    try {
      const userData = localStorage.getItem("user");
      if (userData) user = JSON.parse(userData) as User;
    } catch {
      user = null;
    }

    const days = calculateDays(start, end);

    // ================= API (unified /api/requests) =================
    try {
      const res = await fetch("/api/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: user?.firstName || "Employee",
          email: user?.email || "",
          type: "vacation",
          message: `Vacation from ${start} to ${end} (${days} days)`,
          start,
          end,
          days,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data?.message || "Error sending request");
        return;
      }

      alert("Vacation request sent to admin ✅");
    } catch (err) {
      console.error(err);
      alert("Server error ❌");
      return;
    }

    // ================= PDF =================
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF();

    doc.setFontSize(16);
    doc.text("Vacation Request", 20, 20);

    doc.setFontSize(12);
    doc.text(`Name: ${user?.firstName || "Employee"}`, 20, 40);
    doc.text(`Start Date: ${start}`, 20, 50);
    doc.text(`End Date: ${end}`, 20, 60);
    doc.text(`Total Days: ${days}`, 20, 70);
    doc.text("Status: Pending Approval", 20, 90);

    doc.save("vacation-request.pdf");
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F7FF] to-[#ce908b] flex items-center justify-center p-5">
      <div className="w-full max-w-lg bg-white/60 backdrop-blur-xl p-6 rounded-2xl border border-[#ec510e]/20">
        <h1 className="text-xl font-bold text-[#ec510e] text-center mb-4">
          Request Vacation
        </h1>

        <label className="text-sm text-black">Start Date</label>
        <input
          type="date"
          value={start}
          onChange={(e) => setStart(e.target.value)}
          className="w-full p-3 mb-3 rounded-lg border bg-white text-black"
        />

        <label className="text-sm text-black">End Date</label>
        <input
          type="date"
          value={end}
          onChange={(e) => setEnd(e.target.value)}
          className="w-full p-3 mb-3 rounded-lg border bg-white text-black"
        />

        <button
          onClick={generateReport}
          className="w-full py-3 rounded-full text-white font-semibold bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
        >
          Submit & Download PDF
        </button>

        <button
          onClick={() => router.push("/employee")}
          className="w-full mt-3 py-2 text-sm text-gray-700 underline"
        >
          Back to Dashboard
        </button>
      </div>
    </div>
  );
}
