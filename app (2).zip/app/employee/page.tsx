"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function EmployeeDashboard() {
  const router = useRouter();
type User = {
  firstName?: string;
  email?: string;
  role?: string;
};
const [user, setUser] = useState<User | null>(null);
useEffect(() => {
  const stored = localStorage.getItem("user");

  if (!stored) {
    router.replace("/login");
    return;
  }

  let parsedUser = null;

  try {
    parsedUser = JSON.parse(stored);
  } catch (e) {
    localStorage.removeItem("user");
    router.replace("/login");
    return;
  }

  // 🔥 مهم: تأخير setState يمنع cascading render warning
  setTimeout(() => {
    setUser(parsedUser);
  }, 0);

}, [router]);



function calculate() {
  const salaryEl = document.getElementById("salary") as HTMLInputElement | null;
  const bonusEl = document.getElementById("bonus") as HTMLInputElement | null;
  const absentsEl = document.getElementById("absents") as HTMLInputElement | null;
  const expensesEl = document.getElementById("expenses") as HTMLInputElement | null;

  const salary = parseFloat(salaryEl?.value || "0");
  const bonus = parseFloat(bonusEl?.value || "0");
  const absents = parseFloat(absentsEl?.value || "0");
  const expenses = parseFloat(expensesEl?.value || "0");

  const daily = salary / 30;
  const absentTotal = daily * absents;
  const finalSalary = salary + bonus + expenses - absentTotal;

  const dailyEl = document.getElementById("daily");
  const absentEl = document.getElementById("absentTotal");
  const finalEl = document.getElementById("finalSalary");

  if (dailyEl) dailyEl.innerText = daily.toFixed(2);
  if (absentEl) absentEl.innerText = absentTotal.toFixed(2);
  if (finalEl) finalEl.innerText = finalSalary.toFixed(2);
}

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F7FF] to-[#ce908b] flex justify-center p-4">

      <div className="w-full max-w-5xl flex flex-col gap-6">

        {/* HEADER */}
        <div className="relative bg-white/60 backdrop-blur-xl border border-[#ec510e]/20 rounded-2xl p-6 text-center">

          <button
            onClick={() => router.push("/home")}
            className="absolute left-4 top-4 px-4 py-2 text-sm text-white rounded-full bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
          >
            ← Home
          </button>

          <h1 className="text-2xl font-bold text-[#ec510e] mb-1">
            Employee Dashboard
          </h1>

          <p className="text-sm text-gray-700">
            Welcome dear,
            <span className="font-semibold text-black ml-1">
              {user?.firstName || "Loading..."}
            </span>
          </p>

        </div>

        {/* FORM */}
        <div className="bg-white/60 backdrop-blur-xl border border-[#ec510e]/20 rounded-2xl p-6 grid grid-cols-1 md:grid-cols-2 gap-4">

          <input id="salary" type="number" placeholder="Base Salary"
            className="p-3 rounded-lg border bg-white text-black" />

          <input id="bonus" type="number" placeholder="Bonus"
            className="p-3 rounded-lg border bg-white text-black" />

          <input id="absents" type="number" placeholder="Absent Days"
            className="p-3 rounded-lg border bg-white text-black" />

          <input id="expenses" type="number" placeholder="Expenses"
            className="p-3 rounded-lg border bg-white text-black" />

          <button
            onClick={calculate}
            className="md:col-span-2 py-3 rounded-full text-white font-semibold bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
          >
            Calculate
          </button>

        </div>

        {/* RESULT */}
        <div className="bg-white/60 backdrop-blur-xl border border-[#ec510e]/20 rounded-2xl p-6 text-center">

          <h2 className="text-lg font-semibold text-[#ec510e] mb-4">
            Result
          </h2>

          <p className="text-black">
            Daily Deduction:{" "}
            <span id="daily" className="font-semibold text-black"></span>
          </p>

          <p className="text-black">
            Absent Deduction:{" "}
            <span id="absentTotal" className="font-semibold text-black"></span>
          </p>

          <p className="text-black">
            Final Salary:{" "}
            <span id="finalSalary" className="font-semibold text-black"></span>
          </p>

        </div>

        {/* BUTTONS */}
        <div className="flex flex-wrap justify-center gap-3">

          <button onClick={() => router.push("/veccation")}
            className="px-6 py-3 rounded-full text-white bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]">
            Request Vacation
          </button>

          <button onClick={() => router.push("/appeal")}
            className="px-6 py-3 rounded-full text-white bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]">
            Appliance
          </button>

          <button onClick={() => router.push("/suggestions")}
            className="px-6 py-3 rounded-full text-white bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]">
            Suggestions
          </button>

          <button onClick={() => router.push("/resignation")}
            className="px-6 py-3 rounded-full text-white bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]">
            Resignation
          </button>

        </div>

      </div>
    </div>
  );
}