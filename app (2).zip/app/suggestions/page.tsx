"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Page() {
  const router = useRouter();
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");

  async function sendRequest() {
    let user: { id?: string; firstName?: string; email?: string } | null = null;

    try {
      const storedUser = localStorage.getItem("user");
      if (storedUser) user = JSON.parse(storedUser);
    } catch {
      localStorage.removeItem("user");
    }

    if (!message.trim()) {
      alert("Please write your suggestion");
      return;
    }

    try {
      const res = await fetch("/api/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: user?.firstName || "Employee",
          email: user?.email || "",
          type: "suggestion",
          message,
        }),
      });

      const data = await res.json();

      if (!res.ok) throw new Error(data.message);

      setStatus("Suggestion sent successfully ✅");
      setMessage("");
    } catch (err) {
      console.log(err);
      setStatus("Failed to send suggestion ❌");
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5F7FF] to-[#ce908b] flex items-center justify-center p-5">
      <div className="w-full max-w-lg bg-white/60 backdrop-blur-xl p-6 rounded-2xl border border-[#ec510e]/20">
        <h1 className="text-xl font-bold text-[#ec510e] text-center mb-4">
          Send Suggestion to Manager
        </h1>

        <textarea
          placeholder="Write your suggestion here..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="w-full h-40 p-3 rounded-lg border border-gray-300 outline-none resize-none bg-white/80 text-black placeholder-gray-500"
        />

        <button
          onClick={sendRequest}
          className="w-full mt-4 py-3 rounded-full text-white font-semibold bg-gradient-to-r from-[#ec510e] to-[#ecbcaf]"
        >
          Send Suggestion
        </button>

        <button
          onClick={() => router.push("/employee")}
          className="w-full mt-3 py-2 text-sm text-gray-700 underline"
        >
          Back to Dashboard
        </button>

        <p className="text-center text-sm mt-3 text-gray-600">{status}</p>
      </div>
    </div>
  );
}
