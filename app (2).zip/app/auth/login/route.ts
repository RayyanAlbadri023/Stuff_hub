import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import user from "../../models/user";

import { connectDB } from "@/app/lib/db";

export async function POST(req: Request) {
  await connectDB();

  const { email, password } = await req.json();

  // 🔥 لازم اسم مختلف عن user
  const founduser = await user.findOne({ email });

  if (!founduser) {
    return NextResponse.json(
      { message: "user not found" },
      { status: 404 }
    );
  }

  const match = await bcrypt.compare(password, founduser.password);

  if (!match) {
    return NextResponse.json(
      { message: "Wrong password" },
      { status: 401 }
    );
  }

  return NextResponse.json({
    message: "Login success",
    user: {
      id: founduser._id,
      email: founduser.email,
      role: founduser.role,
    },
  });
}