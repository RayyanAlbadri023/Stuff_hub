import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import user from "../../models/user";

import { connectDB } from "@/app/lib/db";

export async function POST(req: Request) {
  await connectDB();

  const { email, password } = await req.json();

  const exist = await user.findOne({ email });
  if (exist)
    return NextResponse.json({ message: "user exists" }, { status: 400 });

  const hashed = await bcrypt.hash(password, 10);

  await user.create({
    email,
    password: hashed,
    role: "user",
  });

  return NextResponse.json({ message: "Account created" });
}