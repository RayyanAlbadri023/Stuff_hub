import { NextResponse } from "next/server";
import { connectDB } from "@/app/lib/db";
import userModel from "../models/user";

export async function GET(req: Request) {
  await connectDB();

  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json({ error: "No id provided" }, { status: 400 });
  }

  // FIX: validate that id looks like a valid MongoDB ObjectId before querying
  // Otherwise mongoose throws a CastError which was causing the catch block to
  // redirect the user to /login even when they were legitimately logged in
  if (!/^[a-f\d]{24}$/i.test(id)) {
    return NextResponse.json({ error: "Invalid id format" }, { status: 400 });
  }

  try {
    const foundUser = await userModel.findById(id).select("-password");

    if (!foundUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    return NextResponse.json({
      firstName: foundUser.firstName,
      email: foundUser.email,
      role: foundUser.role,
    });
  } catch (err) {
    console.error("/api/me error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
